from django.shortcuts import render_to_response
from django.views.generic import TemplateView
from django.http import HttpResponse, HttpResponseRedirect
#import pymysql
from firstdb.models import Student
from django.template.context_processors import csrf
from django.views import generic
from django.contrib.auth.decorators import login_required


class StudentListView(generic.ListView):
	model = Student

def searchstudentinfo(request):
	searchname = request.POST.get('studentname', '')
	studinfo = Student.objects.filter(student_name = searchname)
	return render_to_response('displaystudent.html', {'studinfo':studinfo})

@login_required(login_url = '/viewtest/login/')
def getstudentinfo(request):
	c = {}
	c.update(csrf(request))
	return render_to_response('addstudentinfo.html', c)

@login_required(login_url = '/viewtest/login/')
def addstudentinfo(request):
	sname = request.POST.get('studentname', '')
	sdate = request.POST.get('birthdate', '')
	s = Student(student_name = sname, student_dob=sdate)
	s.save()
	return render_to_response('addrecord.html')

@login_required(login_url = '/viewtest/login/')
def delstudentinfo(request):
	sname = request.POST.get('studentname', '')
	student = Student.objects.filter(student_name = sname)
	for s in student:
		s.delete()
	return render_to_response('delrecord.html')

@login_required(login_url = '/viewtest/login/')
def requpdatestudentinfo(request):
	c1 = {}
	c1.update(csrf(request))
	studname = request.POST.get('studentname', '')
	request.session['studname'] = studname
	return render_to_response('updatestudentinfo.html',c1)

@login_required(login_url = '/viewtest/login/')
def updatestudentinfo(request):
	newname = request.POST.get('studentname', '')
	newdate = request.POST.get('birthdate','')
	studname = request.session.get('studname')
	Student.objects.filter(student_name = studname).update(student_name = newname, student_dob = newdate)
	return render_to_response('uprecord.html')
 
