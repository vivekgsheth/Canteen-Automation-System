from django.apps import AppConfig


class FirstdbConfig(AppConfig):
    name = 'firstdb'
