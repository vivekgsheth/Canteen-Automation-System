from django.urls import path
from django.conf.urls import url

from . import views

urlpatterns = [
   # path('', views.index, name='index'),
    url(r'^addstudentinfo/$', views.addstudentinfo),
    url(r'^getstudentinfo/$', views.getstudentinfo),
    url(r'^delstudentinfo/$', views.delstudentinfo),
    url(r'^updatestudentinfo/$', views.updatestudentinfo),
    url(r'^requpdatestudentinfo/$', views.requpdatestudentinfo),
    url(r'^searchstudentinfo/$', views.searchstudentinfo),
    path('students/', views.StudentListView.as_view(), name = 'students'),
]
