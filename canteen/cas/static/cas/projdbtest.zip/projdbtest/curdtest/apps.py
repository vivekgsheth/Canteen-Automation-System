from django.apps import AppConfig


class CurdtestConfig(AppConfig):
    name = 'curdtest'
