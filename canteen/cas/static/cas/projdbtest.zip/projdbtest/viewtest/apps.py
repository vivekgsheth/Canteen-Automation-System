from django.apps import AppConfig


class ViewtestConfig(AppConfig):
    name = 'viewtest'
